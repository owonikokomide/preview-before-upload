function previewbeforeupload(id){
  document.querySelector("#"+id).addEventListener("change",function(e){
    if(e.target.files.length ==0){
      return;
    }
    let file = e.target.files[0];
    let url = URL.createObjectURL(file);
    document.querySelector("#"+id+".preview div").innerTEXT = file.name;
    document.querySelector("#"+id+".preview div").src = url;
  });
}
previewbeforeupload("file-1");
previewbeforeupload("file-2");
previewbeforeupload("file-3");
